import React, { useState } from 'react';
import { Plus, Receipt, Calendar, DollarSign, Building, Camera, Eye, Wallet, ClipboardList, X, HardHat } from 'lucide-react';
import { useExpenses } from '../hooks/useExpenses';
import { useProjects } from '../hooks/useProjects';
import { useProjectMembers } from '../hooks/useProjectMembers';
import { useCashAdvances } from '../hooks/useCashAdvances';
import { useSubcontractors } from '../hooks/useSubcontractors';
import { useAuth } from '../hooks/useAuth';
import { EXPENSE_CATEGORIES, SUBCONTRACTOR_TRADES } from '../utils/constants';
import { ReceiptUpload } from './ReceiptUpload';

type Mode = 'expense' | 'petty-cash';
const ADD_NEW_SUBCONTRACTOR = '__add_new__';

export const AddExpense: React.FC = () => {
  const { user, isAdmin } = useAuth();
  const { addExpense, expenses } = useExpenses();
  const { projects } = useProjects();
  const [mode, setMode] = useState<Mode>('expense');

  const [formData, setFormData] = useState({
    projectId: '',
    category: '',
    description: '',
    amount: '',
    date: new Date().toISOString().split('T')[0],
    receipt: '',
    subcontractorId: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showReceiptUpload, setShowReceiptUpload] = useState(false);
  const [receiptImage, setReceiptImage] = useState<string | null>(null);
  const [showFullReceipt, setShowFullReceipt] = useState(false);

  // Subcontractor selection - required when category is "subcontractor"
  const { subcontractors, addSubcontractor } = useSubcontractors(formData.projectId || null);
  const [showAddSubcontractor, setShowAddSubcontractor] = useState(false);
  const [newSubName, setNewSubName] = useState('');
  const [newSubTrade, setNewSubTrade] = useState(SUBCONTRACTOR_TRADES[0]);
  const [newSubContractValue, setNewSubContractValue] = useState('');
  const [subSubmitting, setSubSubmitting] = useState(false);
  const [subError, setSubError] = useState<string | null>(null);

  // Petty cash form state
  const [pettyProjectId, setPettyProjectId] = useState('');
  const [pettyRecipientId, setPettyRecipientId] = useState('');
  const [pettyAmount, setPettyAmount] = useState('');
  const [pettyDate, setPettyDate] = useState(new Date().toISOString().split('T')[0]);
  const [pettyNotes, setPettyNotes] = useState('');
  const [pettySubmitting, setPettySubmitting] = useState(false);

  const { members: pettyMembers } = useProjectMembers(pettyProjectId || null);
  const { addAdvance } = useCashAdvances(pettyProjectId || null);
  const pettyActiveMembers = pettyMembers.filter((m) => m.userId);

  const pettyProject = projects.find((p) => p.id === pettyProjectId);
  const canGivePettyCash = pettyProject && user && (pettyProject.ownerId === user.id || isAdmin);

  // Live petty cash balance for the "Log Expense" form, for the person currently logging it.
  // This only applies to team members who receive float - not the project manager/owner.
  const selectedProject = projects.find((p) => p.id === formData.projectId);
  const isOwnerOfSelectedProject = !!(
    selectedProject &&
    user &&
    (selectedProject.ownerId === user.id || isAdmin)
  );

  const { advances: myAdvances } = useCashAdvances(formData.projectId || null);
  const myFloatGiven = user
    ? myAdvances.filter((a) => a.recipientId === user.id).reduce((sum, a) => sum + a.amount, 0)
    : 0;
  const mySpentSoFar = user
    ? expenses
        .filter((e) => e.projectId === formData.projectId && e.userId === user.id)
        .reduce((sum, e) => sum + e.amount, 0)
    : 0;
  const myBalanceBeforeThis = myFloatGiven - mySpentSoFar;
  const thisAmount = parseFloat(formData.amount) || 0;
  const myBalanceAfterThis = myBalanceBeforeThis - thisAmount;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.projectId || !formData.category || !formData.description || !formData.amount) {
      alert('Please fill in all required fields');
      return;
    }

    if (formData.category === 'subcontractor' && !formData.subcontractorId) {
      alert('Please select which subcontractor this payment is for.');
      return;
    }

    setIsSubmitting(true);

    try {
      await addExpense({
        projectId: formData.projectId,
        category: formData.category,
        description: formData.description.trim(),
        amount: parseFloat(formData.amount),
        date: formData.date,
        receipt: formData.receipt.trim() || undefined,
        receiptImage: receiptImage || undefined,
        subcontractorId: formData.category === 'subcontractor' ? formData.subcontractorId : undefined,
      });

      setReceiptImage(null);

      // Reset form
      setFormData({
        projectId: '',
        category: '',
        description: '',
        amount: '',
        date: new Date().toISOString().split('T')[0],
        receipt: '',
        subcontractorId: '',
      });

      alert('Expense added successfully!');
    } catch (error) {
      alert('Error adding expense. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handlePettySubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!pettyProjectId || !pettyRecipientId || !pettyAmount) {
      alert('Please fill in all required fields');
      return;
    }

    setPettySubmitting(true);

    try {
      await addAdvance({
        recipientId: pettyRecipientId,
        amount: parseFloat(pettyAmount),
        date: pettyDate,
        notes: pettyNotes.trim() || undefined,
      });

      setPettyRecipientId('');
      setPettyAmount('');
      setPettyNotes('');
      setPettyDate(new Date().toISOString().split('T')[0]);

      alert('Cash advance recorded. This float will not be counted as a project expense - only what the team member actually spends and logs will show up as an expense.');
    } catch (error) {
      alert(error instanceof Error ? error.message : 'Error recording cash advance. Please try again.');
    } finally {
      setPettySubmitting(false);
    }
  };

  const handleSubcontractorSelect = (value: string) => {
    if (value === ADD_NEW_SUBCONTRACTOR) {
      setNewSubName('');
      setNewSubTrade(SUBCONTRACTOR_TRADES[0]);
      setNewSubContractValue('');
      setSubError(null);
      setShowAddSubcontractor(true);
      return;
    }
    setFormData((prev) => ({ ...prev, subcontractorId: value }));
  };

  const handleAddSubcontractor = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSubName.trim() || !newSubContractValue) return;

    setSubError(null);
    setSubSubmitting(true);
    try {
      const created = await addSubcontractor({
        name: newSubName.trim(),
        trade: newSubTrade,
        contractValue: parseFloat(newSubContractValue),
      });
      setFormData((prev) => ({ ...prev, subcontractorId: created.id }));
      setShowAddSubcontractor(false);
    } catch (err) {
      setSubError(err instanceof Error ? err.message : 'Could not add subcontractor.');
    } finally {
      setSubSubmitting(false);
    }
  };

  const handleReceiptProcessed = (data: { amount?: number; receiptNumber?: string; imageUrl: string }) => {
    // Auto-fill form with extracted data
    if (data.amount) {
      setFormData(prev => ({ ...prev, amount: data.amount!.toString() }));
    }
    if (data.receiptNumber) {
      setFormData(prev => ({ ...prev, receipt: data.receiptNumber! }));
    }

    setReceiptImage(data.imageUrl);
    setShowReceiptUpload(false);
  };

  return (
    <div className="space-y-6 pb-4">
      {/* Header */}
      <div>
        <h1 className="text-xl lg:text-2xl font-bold text-white">Add Expense</h1>
        <p className="text-sm lg:text-base text-gray-400">Record a new construction expense or give petty cash to a team member</p>
      </div>

      {/* Mode toggle */}
      <div className="flex bg-gray-800 rounded-lg p-1 border border-gray-700">
        <button
          type="button"
          onClick={() => setMode('expense')}
          className={`flex-1 py-2.5 rounded-md text-sm font-medium transition-colors inline-flex items-center justify-center gap-2 ${
            mode === 'expense' ? 'bg-yellow-500 text-black' : 'text-gray-300'
          }`}
        >
          <ClipboardList className="h-4 w-4" />
          Log Expense
        </button>
        <button
          type="button"
          onClick={() => setMode('petty-cash')}
          className={`flex-1 py-2.5 rounded-md text-sm font-medium transition-colors inline-flex items-center justify-center gap-2 ${
            mode === 'petty-cash' ? 'bg-yellow-500 text-black' : 'text-gray-300'
          }`}
        >
          <Wallet className="h-4 w-4" />
          Give Petty Cash
        </button>
      </div>

      {mode === 'expense' ? (
        <>
          {/* Expense Form */}
          <div className="bg-gray-800 rounded-lg p-4 lg:p-6 border border-gray-700">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Project Selection */}
              <div>
                <label className="block text-xs lg:text-sm font-medium text-gray-300 mb-2">
                  <Building className="h-4 w-4 inline mr-2" />
                  Project *
                </label>
                <select
                  value={formData.projectId}
                  onChange={(e) => setFormData({ ...formData, projectId: e.target.value })}
                  className="w-full px-3 py-2 lg:py-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-yellow-500 text-sm lg:text-base"
                  required
                >
                  <option value="">Select a project</option>
                  {projects.map((project) => (
                    <option key={project.id} value={project.id}>
                      {project.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Category Selection */}
              <div>
                <label className="block text-xs lg:text-sm font-medium text-gray-300 mb-2">
                  Category *
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2 lg:gap-3">
                  {EXPENSE_CATEGORIES.map((category) => (
                    <button
                      key={category.id}
                      type="button"
                      onClick={() => setFormData({ ...formData, category: category.id, subcontractorId: '' })}
                      className={`p-2 lg:p-3 rounded-lg border transition-colors text-left ${
                        formData.category === category.id
                          ? 'border-yellow-500 bg-yellow-500 bg-opacity-20 text-yellow-500'
                          : 'border-gray-600 bg-gray-700 hover:bg-gray-600 text-gray-300'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-xs lg:text-sm font-medium">{category.name}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Subcontractor Selection - required for the Subcontractor category */}
              {formData.category === 'subcontractor' && (
                <div>
                  <label className="block text-xs lg:text-sm font-medium text-gray-300 mb-2">
                    <HardHat className="h-4 w-4 inline mr-2" />
                    Subcontractor *
                  </label>
                  <select
                    value={formData.subcontractorId}
                    onChange={(e) => handleSubcontractorSelect(e.target.value)}
                    className="w-full px-3 py-2 lg:py-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-yellow-500 text-sm lg:text-base"
                    required
                  >
                    <option value="">Select subcontractor</option>
                    {subcontractors.map((sub) => (
                      <option key={sub.id} value={sub.id}>
                        {sub.name} ({sub.trade})
                      </option>
                    ))}
                    <option value={ADD_NEW_SUBCONTRACTOR}>+ Add New Subcontractor</option>
                  </select>
                  {!formData.projectId && (
                    <p className="text-xs text-gray-500 mt-1">Select a project first.</p>
                  )}
                </div>
              )}

              {/* Amount and Date */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs lg:text-sm font-medium text-gray-300 mb-2">
                    <DollarSign className="h-4 w-4 inline mr-2" />
                    Amount *
                  </label>
                  <input
                    type="number"
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                    className="w-full px-3 py-2 lg:py-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-yellow-500 text-sm lg:text-base"
                    placeholder="0.00"
                    step="0.01"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs lg:text-sm font-medium text-gray-300 mb-2">
                    <Calendar className="h-4 w-4 inline mr-2" />
                    Date *
                  </label>
                  <input
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    className="w-full px-3 py-2 lg:py-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-yellow-500 text-sm lg:text-base"
                    required
                  />
                </div>
              </div>

              {/* Petty cash balance indicator - team members only, not the project owner */}
              {formData.projectId && thisAmount > 0 && !isOwnerOfSelectedProject && (
                <div
                  className={`rounded-lg p-3 border text-sm ${
                    myBalanceAfterThis < 0
                      ? 'bg-red-500 bg-opacity-10 border-red-500 text-red-400'
                      : 'bg-yellow-500 bg-opacity-10 border-yellow-500 text-yellow-500'
                  }`}
                >
                  {myBalanceAfterThis < 0 ? (
                    <>
                      <p className="flex items-center gap-2 font-medium">
                        <Wallet className="h-4 w-4" />
                        {myFloatGiven > 0
                          ? `This is $${Math.abs(myBalanceAfterThis).toLocaleString()} more than the petty cash you were given`
                          : `You haven't been given any petty cash for this project yet`}
                      </p>
                      <p className="mt-1 text-xs">
                        That ${Math.abs(myBalanceAfterThis).toLocaleString()} will be recorded as paid from your own
                        pocket - the project will owe it back to you. The owner can see this under Cash Flow.
                      </p>
                    </>
                  ) : (
                    <p className="flex items-center gap-2 font-medium">
                      <Wallet className="h-4 w-4" />
                      After this, you'll still have ${myBalanceAfterThis.toLocaleString()} of petty cash left for this
                      project
                    </p>
                  )}
                </div>
              )}

              {/* Description */}
              <div>
                <label className="block text-xs lg:text-sm font-medium text-gray-300 mb-2">
                  Description *
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={3}
                  className="w-full px-3 py-2 lg:py-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-yellow-500 text-sm lg:text-base"
                  placeholder="Enter expense description"
                  required
                />
              </div>

              {/* Receipt */}
              <div>
                <div className="space-y-3">
                  <label className="block text-xs lg:text-sm font-medium text-gray-300">
                    <Receipt className="h-4 w-4 inline mr-2" />
                    Receipt (Optional)
                  </label>

                  <div className="flex flex-col sm:flex-row gap-3">
                    <input
                      type="text"
                      value={formData.receipt}
                      onChange={(e) => setFormData({ ...formData, receipt: e.target.value })}
                      className="flex-1 px-3 py-2 lg:py-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-yellow-500 text-sm lg:text-base"
                      placeholder="Enter receipt number"
                    />
                    <button
                      type="button"
                      onClick={() => setShowReceiptUpload(true)}
                      className="px-4 py-2 lg:py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors inline-flex items-center gap-2 text-sm lg:text-base whitespace-nowrap"
                    >
                      <Camera className="h-4 w-4" />
                      Scan Receipt
                    </button>
                  </div>

                  {receiptImage && (
                    <div className="relative inline-block">
                      <img
                        src={receiptImage}
                        alt="Receipt"
                        className="w-20 h-20 lg:w-24 lg:h-24 object-cover rounded-lg border border-gray-600"
                      />
                      <button
                        type="button"
                        onClick={() => setShowFullReceipt(true)}
                        className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center rounded-lg opacity-0 hover:opacity-100 transition-opacity"
                      >
                        <Eye className="h-6 w-6 text-white" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setReceiptImage(null)}
                        className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm hover:bg-red-600 transition-colors"
                      >
                        ×
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isSubmitting}
                className={`w-full py-3 lg:py-4 px-4 rounded-lg font-medium transition-colors text-sm lg:text-base ${
                  isSubmitting
                    ? 'bg-gray-600 text-gray-400 cursor-not-allowed'
                    : 'bg-yellow-500 hover:bg-yellow-600 text-black'
                }`}
              >
                {isSubmitting ? (
                  'Adding Expense...'
                ) : (
                  <>
                    <Plus className="h-4 w-4 inline mr-2" />
                    Add Expense
                  </>
                )}
              </button>
            </form>
          </div>

          {/* Add New Subcontractor Modal */}
          {showAddSubcontractor && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
              <div className="bg-gray-800 rounded-lg p-4 lg:p-6 max-w-md w-full border border-gray-700">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-base lg:text-lg font-semibold text-white">Add New Subcontractor</h3>
                  <button
                    onClick={() => setShowAddSubcontractor(false)}
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    <X className="h-6 w-6" />
                  </button>
                </div>

                <form onSubmit={handleAddSubcontractor} className="space-y-4">
                  <div>
                    <label className="block text-xs lg:text-sm font-medium text-gray-300 mb-2">
                      Subcontractor Name *
                    </label>
                    <input
                      type="text"
                      value={newSubName}
                      onChange={(e) => setNewSubName(e.target.value)}
                      placeholder="e.g. Ali Plumbing"
                      className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-yellow-500 text-sm"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs lg:text-sm font-medium text-gray-300 mb-2">Trade</label>
                    <select
                      value={newSubTrade}
                      onChange={(e) => setNewSubTrade(e.target.value)}
                      className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-yellow-500 text-sm"
                    >
                      {SUBCONTRACTOR_TRADES.map((trade) => (
                        <option key={trade} value={trade}>
                          {trade}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs lg:text-sm font-medium text-gray-300 mb-2">
                      Contract Value (RM) *
                    </label>
                    <input
                      type="number"
                      value={newSubContractValue}
                      onChange={(e) => setNewSubContractValue(e.target.value)}
                      placeholder="0.00"
                      step="0.01"
                      className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-yellow-500 text-sm"
                      required
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      The agreed total sub value - so this app can track what's paid vs left owing.
                    </p>
                  </div>

                  {subError && <p className="text-red-500 text-sm">{subError}</p>}

                  <button
                    type="submit"
                    disabled={subSubmitting}
                    className="w-full bg-yellow-500 hover:bg-yellow-600 disabled:opacity-50 text-black px-4 py-2.5 rounded-lg font-medium transition-colors text-sm"
                  >
                    {subSubmitting ? 'Adding...' : 'Add Subcontractor'}
                  </button>
                </form>
              </div>
            </div>
          )}

          {/* Receipt Upload Modal */}
          {showReceiptUpload && (
            <ReceiptUpload
              onReceiptProcessed={handleReceiptProcessed}
              onClose={() => setShowReceiptUpload(false)}
            />
          )}

          {/* Full-size receipt preview */}
          {showFullReceipt && receiptImage && (
            <div
              className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center p-4 z-50"
              onClick={() => setShowFullReceipt(false)}
            >
              <div className="relative max-w-2xl w-full">
                <button
                  onClick={() => setShowFullReceipt(false)}
                  className="absolute -top-10 right-0 text-gray-300 hover:text-white transition-colors"
                  title="Close"
                >
                  <X className="h-8 w-8" />
                </button>
                <img
                  src={receiptImage}
                  alt="Receipt"
                  className="w-full max-h-[85vh] object-contain rounded-lg"
                  onClick={(e) => e.stopPropagation()}
                />
              </div>
            </div>
          )}

          {/* Quick Tips */}
          <div className="bg-gray-800 rounded-lg p-4 lg:p-6 border border-gray-700">
            <h3 className="text-base lg:text-lg font-semibold text-white mb-3">Quick Tips</h3>
            <div className="space-y-2 text-xs lg:text-sm text-gray-400">
              <p>• Make sure to select the correct project before adding expenses</p>
              <p>• Use descriptive names for better expense tracking</p>
              <p>• Scan receipts to automatically extract amounts and receipt numbers</p>
              <p>• Double-check amounts before submitting</p>
              <p>• Giving cash to a team member to buy things? Use "Give Petty Cash" instead - it won't be double-counted</p>
            </div>
          </div>
        </>
      ) : (
        <>
          {/* Petty Cash Form */}
          <div className="bg-gray-800 rounded-lg p-4 lg:p-6 border border-gray-700">
            <form onSubmit={handlePettySubmit} className="space-y-6">
              <div>
                <label className="block text-xs lg:text-sm font-medium text-gray-300 mb-2">
                  <Building className="h-4 w-4 inline mr-2" />
                  Project *
                </label>
                <select
                  value={pettyProjectId}
                  onChange={(e) => {
                    setPettyProjectId(e.target.value);
                    setPettyRecipientId('');
                  }}
                  className="w-full px-3 py-2 lg:py-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-yellow-500 text-sm lg:text-base"
                  required
                >
                  <option value="">Select a project</option>
                  {projects.map((project) => (
                    <option key={project.id} value={project.id}>
                      {project.name}
                    </option>
                  ))}
                </select>
              </div>

              {pettyProjectId && !canGivePettyCash && (
                <p className="text-sm text-yellow-500">
                  Only the project owner can give out petty cash. Ask them to record this instead.
                </p>
              )}

              {pettyProjectId && canGivePettyCash && (
                <>
                  <div>
                    <label className="block text-xs lg:text-sm font-medium text-gray-300 mb-2">
                      Give To *
                    </label>
                    <select
                      value={pettyRecipientId}
                      onChange={(e) => setPettyRecipientId(e.target.value)}
                      className="w-full px-3 py-2 lg:py-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-yellow-500 text-sm lg:text-base"
                      required
                    >
                      <option value="">Select team member</option>
                      {pettyActiveMembers.map((m) => (
                        <option key={m.id} value={m.userId ?? ''}>
                          {m.name || m.email}
                        </option>
                      ))}
                    </select>
                    {pettyActiveMembers.length === 0 && (
                      <p className="text-xs text-gray-500 mt-1">
                        No active team members on this project yet. Add someone under Projects → Manage Team first.
                      </p>
                    )}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs lg:text-sm font-medium text-gray-300 mb-2">
                        <DollarSign className="h-4 w-4 inline mr-2" />
                        Amount *
                      </label>
                      <input
                        type="number"
                        value={pettyAmount}
                        onChange={(e) => setPettyAmount(e.target.value)}
                        className="w-full px-3 py-2 lg:py-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-yellow-500 text-sm lg:text-base"
                        placeholder="0.00"
                        step="0.01"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs lg:text-sm font-medium text-gray-300 mb-2">
                        <Calendar className="h-4 w-4 inline mr-2" />
                        Date *
                      </label>
                      <input
                        type="date"
                        value={pettyDate}
                        onChange={(e) => setPettyDate(e.target.value)}
                        className="w-full px-3 py-2 lg:py-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-yellow-500 text-sm lg:text-base"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs lg:text-sm font-medium text-gray-300 mb-2">
                      Notes (Optional)
                    </label>
                    <textarea
                      value={pettyNotes}
                      onChange={(e) => setPettyNotes(e.target.value)}
                      rows={2}
                      className="w-full px-3 py-2 lg:py-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-yellow-500 text-sm lg:text-base"
                      placeholder="e.g. for buying materials this week"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={pettySubmitting}
                    className={`w-full py-3 lg:py-4 px-4 rounded-lg font-medium transition-colors text-sm lg:text-base ${
                      pettySubmitting
                        ? 'bg-gray-600 text-gray-400 cursor-not-allowed'
                        : 'bg-yellow-500 hover:bg-yellow-600 text-black'
                    }`}
                  >
                    {pettySubmitting ? (
                      'Recording...'
                    ) : (
                      <>
                        <Wallet className="h-4 w-4 inline mr-2" />
                        Give Petty Cash
                      </>
                    )}
                  </button>
                </>
              )}
            </form>
          </div>

          <div className="bg-gray-800 rounded-lg p-4 lg:p-6 border border-gray-700">
            <h3 className="text-base lg:text-lg font-semibold text-white mb-3">How this works</h3>
            <div className="space-y-2 text-xs lg:text-sm text-gray-400">
              <p>• This records money you handed to a team member - it does NOT count as a project expense</p>
              <p>• When they actually buy something, they log it under "Log Expense" as usual</p>
              <p>• Open a project's Cash Flow view to see how much each person is still holding vs has spent</p>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
